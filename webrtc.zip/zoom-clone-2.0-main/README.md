# zoom-clone-2.0

## Features
- Inro page (Host a meeting or join a meeting page)
- Name Feature(You can see names of participants)
- Video and Voice chat
- Live chat
- Invite Participants
- close/Open Video
- Mute/UnMute Audio

https://user-images.githubusercontent.com/66161239/125756026-ae72e99b-171a-4155-bbed-37d1219c6d1c.mp4

## Test 
- Windows

## How to run
- git clone https://github.com/harsh317/zoom-clone-2.0.git
- cd zoom-clone-2.0
- npm server.js
- Go to LocalHost:3030

## tutorial
https://medium.com/nerd-for-tech/full-stack-zoom-clone-943289af8f7d

## Wanna allow Other people to join
- Use ngrok or deploy your app on heroku
